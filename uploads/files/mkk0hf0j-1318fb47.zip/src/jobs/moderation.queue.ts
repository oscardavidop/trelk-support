import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';

@Injectable()
export class ModerationQueue {
  private queue: Queue;

  constructor() {
    this.queue = new Queue('image-moderation', {
      connection: {
        host: 'localhost',
        port: 6379,
      },
    });
  }

  async addImageToModerate(data: { imageUrl: string }) {
    await this.queue.add('moderate-image', data);
  }
}