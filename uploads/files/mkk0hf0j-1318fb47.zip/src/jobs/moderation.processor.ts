import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { SightengineService } from '../services/sightengine.service';

@Processor('image-moderation')
export class ModerationProcessor extends WorkerHost {
  constructor(private readonly sightengineService: SightengineService) {
    super();
  }

  async process(job: Job) {
    const { imageUrl } = job.data;
    console.log('Processing image:', imageUrl);
    const result = await this.sightengineService.moderateImage(imageUrl);
    console.log('Moderation result:', result);
  }
}