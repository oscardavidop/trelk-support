import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { WebhookController } from './webhook/webhook.controller';
import { WebhookService } from './webhook/webhook.service';
import { ModerationQueue } from './jobs/moderation.queue';
import { ModerationProcessor } from './jobs/moderation.processor';
import { SightengineService } from './services/sightengine.service';

@Module({
  imports: [
    BullModule.forRoot({
      connection: {
        host: 'localhost',
        port: 6379,
      },
    }),
  ],
  controllers: [WebhookController],
  providers: [WebhookService, ModerationQueue, ModerationProcessor, SightengineService],
})
export class AppModule {}