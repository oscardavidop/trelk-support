import { Controller, Post, Body } from '@nestjs/common';
import { WebhookService } from './webhook.service';

@Controller('webhook')
export class WebhookController {
  constructor(private readonly webhookService: WebhookService) {}

  @Post('uploadcare')
  async handleUploadcareWebhook(@Body() body: any) {
    await this.webhookService.enqueueImageModeration(body);
    return { ok: true };
  }
}