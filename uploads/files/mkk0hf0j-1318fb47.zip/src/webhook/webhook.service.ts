import { Injectable } from '@nestjs/common';
import { ModerationQueue } from '../jobs/moderation.queue';

@Injectable()
export class WebhookService {
  constructor(private readonly moderationQueue: ModerationQueue) {}

  async enqueueImageModeration(data: any) {
    const imageUrl = data?.cdn_url || data?.url || data?.file_url;
    if (imageUrl) {
      await this.moderationQueue.addImageToModerate({ imageUrl });
    }
  }
}