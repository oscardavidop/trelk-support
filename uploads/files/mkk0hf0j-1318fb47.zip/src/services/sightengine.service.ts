import { Injectable } from '@nestjs/common';
import axios from 'axios';

@Injectable()
export class SightengineService {
  private apiUser = 'your_api_user';
  private apiSecret = 'your_api_secret';

  async moderateImage(imageUrl: string) {
    const response = await axios.get('https://api.sightengine.com/1.0/check.json', {
      params: {
        url: imageUrl,
        models: 'nudity,wad,offensive,text-content',
        api_user: this.apiUser,
        api_secret: this.apiSecret,
      },
    });
    return response.data;
  }
}